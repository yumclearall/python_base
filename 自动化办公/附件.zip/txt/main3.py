# 设置文件夹的相对路径
path = './工作文件夹/'
# 将'05_20_2020会议记录.txt'赋值给file_name
file_name = '05_20_2020会议记录.txt'
# 字符串拼接，获得txt文件的相对路径
target_file = 
# 打印相对路径
print()
