# 导入os模块
import os
# 设置目标文件夹路径
path = './工作文件夹/'
# 获取文件夹下的所有文件名
files_list = os.listdir(path)
# 打印看看都有哪些文件
print(files_list)