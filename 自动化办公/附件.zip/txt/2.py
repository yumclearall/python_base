# 导入os模块
import os

# 设置文件夹路径，获取文件夹下的所有文件和文件夹名称
path = './工作文件夹/'
files_list = os.listdir(path)

'''补充代码，打印出所有 txt 类型的文件名'''
# 循环遍历每一个文件和文件夹名称

    # 判断文件名中是否包含'.txt'

    	# 找到文件时先打印提示
        print("找到了文件：" + file_name)