# 目标文件是工作文件夹内的 06_01_2020会议记录.txt 文本文件
target_file = './工作文件夹/06_01_2020会议记录.txt'
# 使用 open() 函数打开 06_01_2020会议记录.txt 文本文件
file = open(target_file, 'r', encoding='utf-8')
# 使用 文件对象.read() 方法读取文件内容
content = file.read()
# 关闭文件对象
file.close()
# 设置需要查找的关键词
key_word = input("请输入要查找的关键词：")
# 判断关键词是否在文件内容中
if key_word in content:
    # 匹配到关键词时先打印提示
    print("妙啊，文件**{}**包含了关键词：{}".format(target_file, key_word))