# 导入 pandas 模块并将其简化为 pd
import pandas as pd
# 导入pyplot模块
from matplotlib import pyplot as plt
# 设置显示中文字体
plt.rcParams['font.family'] = ['SimHei']
# 生成画布，并设置画布的大小为(6, 6)
plt.figure(figsize=(6,6))
# 设置 x/y坐标
x = pd.Series(['就业几率较高', '就业薪资较高','专业具有多样性','多就业偏金融性职位','专业素养要求较高','就业范围广泛', '多就业偏计算机性职位','业绩要求相对较低','其他'])
y = pd.Series([ 90,142,156,68,53,41,30,24,49])
y1=pd.Series(['90','142','156','68','53','41','30','24','49'])
colors = ['cornflowerblue','yellowgreen','peru' ,'gold','salmon','orange','pink','aqua','tan']
# 绘制柱状图
plt.bar(y1,height=y,color=colors,alpha=0.6)
# 绘制折线图
plt.plot(y1,y, color='dodgerblue')
# 设置图表标题名为'图'，字体大小为 20
plt.title('计算机行业--金融科技专业--就业分析调查结果',fontsize=20)
# 设置坐标轴的刻度字体大小为 12
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
# 设置 x、y 轴标题分别为''、'，字体大小均为 15
plt.xlabel('人数',fontsize=15)
# 设置数据标签，标签内容是 y 坐标值
for x,y,y1 in zip(x,y,y1):
    plt.text(y1,y,x,ha='center',va='bottom',fontsize=10)
# 设置画布保存路径为'./工作/.png'
plt.savefig('工作/行业--就业分析调查结果柱状图.png')


#plt.plot(x, y, linewidth=3, color='r', marker='o',markersize=10, markerfacecolor='w')